JD Edwards Anypoint&trade; Studio Connector Demo (Invoke Business Function)
==================================================================

## Introduction

The current demo application provides a simple workflow to:

* Adding a Customer in JDE

![Flow Get](images/bsfn-trans-01-flow.png)

This operation will invoke to A/B Master Business Function on EnterpriseOne Server

## Prerequisites

* JDE Connector User manual has been read (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html): _ModusBox’s JDE Connector_)
* JDE bundle must be created. (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html#generate-bundle): _Generate Bundle_)
* JDE standards ini files (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html#copy-jde-ini-files-inside-the-project): _Copy JDE ini Files to the Projet_)
* JDE Enterprise Server is reachable from your location

## Import the project

* Click File &rarr; Import
* On the next screen, click "Packaged mule application (.jar)" &rarr; Next.
* You can now import the demo jar on the next screen.  Locate the demo/ directory from the codebase, and add the demo jar file. Assign the demo a project name. 

![Import Packaged Mule Application](images/01-Import-jar-file.png)
 
![Import Mule Project](images/02-Import-jar-file.png)

## Set Cookbook credentials inside the file

`src/main/app/jde.properties`.

```
jde.user=<JDE_USER>
jde.password=<JDE_PASSWORD>
jde.environment=<JDE_ENVIRONMENT>
jde.role=<JDE_ROLE> 
```

## Copy **JDE ini Files** inside the Project.

Put the files inside the project folder in the folder:

* source/main/resource/<JDE-ENVIRONMENT>

![Copy Ini Files](images/bsfn-trans-02-copy-ini-files.png)
 

## Update Dependencies ##

*Important Note*: For the demo application, you'll need to update library dependencies.

```
<dependency>
	<groupId>com.modus</groupId>
	<artifactId>mule-jde-connector</artifactId>
	<version>2.0.0</version>
	<classifier>mule-plugin</classifier>
</dependency>
``` 

```
<dependency>
	<groupId>com.jdedwards</groupId>
	<artifactId>jde-lib-bundle</artifactId>
	<version>1.0.0</version>
	<classifier>mule-4</classifer>
</dependency>
``` 

## Test Connection ##

* Under Global Element, click "Edit" for "JDE Config"
* On the next screen, click "Test Connection". 

![Test Connection](images/04-Test-Connection.png)

* A successful message should pop-up.
 
![Test Connection Popup](images/05-Test-Connection-Popup.png)
 
## To Test the Example ##

* Save the project.
* Run the project by right- or Ctrl-clicking the project name at left, the Run As → Mule Application.

![Test Connection Popup](images/bsfn-trans-03-run-as.png)

* Open a browser and access the URL `http://localhost:8081`. You should see the demo application deployed.
* To fetch an address book data, enter JDE address book number:
* Click the **"Get Address Book"** button and wait a few moments to finish processing.
* The details of the employee will be displayed in the **Description** textarea.
 
![Test Connection Popup](images/bsfn-trans-04-form.png)
 
## About the flows

**1. Html_Form_Flow:** renders the HTML form with a `parseTemplate` component.

![Flow HMTL Form](images/09-Flow-Form.png)
 
**3. Get Address Book Data:** retrieves the information of an address book invoking **A/B Master Business Function** in Inquired Mode

![Flow Get](images/bsfn-trans-01-flow.png)
 
* **Congratulations!** You have successfully run this demo.
