
JD Edwards Anypoint&trade; Studio Connector Demo (Submit Batch Job)
==================================================================

## Introduction

The current demo application provides a simple workflow to:

* Submit the R0008P XJDE0001 Batch Job

![Main Flow](images/MainFlow.png)

This operation will submit a batch job on the EnterpriseOne Server

## Prerequisites

* JDE Connector User manual has been read (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html): _ModusBox’s JDE Connector_)
* JDE bundle must be created. (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html#generate-bundle): _Generate Bundle_)
* JDE standard configuration (.ini & .properties) files (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html#copy-jde-ini-files-inside-the-project): _Copy JDE ini Files to the Projet_)
* JDE Enterprise Server is reachable from your location

## Import the project

* Click File &rarr; Import
* On the next screen, click "Packaged mule application (.jar)" &rarr; Next.

![Import Packaged Mule Application](images/ImportProject.png)

* You can now import the demo jar on the next screen.  Locate the demo/ directory from the code base, and add the demo jar file. Assign the demo a project name. 

![Import Mule Project](images/ImportProjectName.png)

## Set Cookbook credentials inside the file `src/main/app/jde.properties`.

```
jde.user=<YOUR_JDE_USER>
jde.password=<YOUR_JDE_PASSWORD>
jde.environment=<YOUR_JDE_ENVIRONMENT>
jde.role=<YOUR_JDE_ROLE> 
```

## Copy **JDE ini Files** inside the Project.

The following files need to be located
*	jdbj.ini
*	jdeinterop.ini
*	tnsnames.ora (for Oracle databases only)

Copy these file to your resources folder, as per the enviroment being used to run the demo eg. JDV920
* source/main/resources/**JDV920**

![Copy Ini Files](images/src_main_resources.png)
 

## Update Dependencies ##

*Important Note*: For the demo application, you'll need to update library dependencies (pom.xml in the project root folder) . 
```
<dependency>
	<groupId>com.modus</groupId>
	<artifactId>mule-jde-connector</artifactId>
	<version>2.0.0</version>
	<classifier>mule-plugin</classifier>
</dependency>
``` 
```
<dependency>
	<groupId>com.jdedwards</groupId>
	<artifactId>jde-lib-bundle</artifactId>
	<version>1.0.0</version>
	<classifier>mule-4</classifer>
</dependency>

``` 

## Test Connection ##

* Go to the Global Element tab, select the **"JDE Config"** element, and click "Edit"
* On the button panel the bottom of the window, click **"Test Connection..."**

![Test Connection](images/TestConnection.png)

* If the connection succeeded, you should see the below message.
 
![Test Connection Popup](images/ConnectionSuccess.png)
 
## Testing the Demo ##

* Save the project.
* To run the project, right-click the project name in the project explorer view, select Run As → Mule Application.

![Test Connection Popup](images/RunAs.png)

* Open a browser and access the URL `http://localhost:8081`. You should see the demo application deployed.
* To submit the batch job, click the **"Submit Batch Job"** button and wait a few moments to finish processing.
* The batch job number should be displayed in the **Description** text area.
 
![Test Connection Popup](images/Form.png)
 
## About the flows

**1. Html_Form_Flow:** Renders the HTML form with a `parseTemplate` component.

![Flow HMTL Form](images/FormFlow.png)
 
**2. demo-portx-jde-ube-submitFlow:** Submits a batch job for **R0008P XJDE0001** and returns the batch job number.

![Flow Get](images/MainFlow.png)
 
* **Congratulations!** You have successfully run this demo.
