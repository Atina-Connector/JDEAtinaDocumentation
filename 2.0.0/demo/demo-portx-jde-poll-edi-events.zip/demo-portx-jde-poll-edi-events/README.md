
JD Edwards Anypoint&trade; Studio Connector Demo (Poll For EDI Events)
==================================================================

## Introduction

The current demo application provides a simple workflow to:

* Polls for Purchase Order EDI Events

![Main Flow](images/MainFlow.png)

This operation will Poll for Purchase Order EDI Events from the EnterpriseOne Server

## Prerequisites

* JDE Connector User manual has been read (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html): _ModusBox’s JDE Connector_)
* JDE bundle must be created. (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html#generate-bundle): _Generate Bundle_)
* JDE standard configuration (.ini & .properties) files (See [User Manual Site](http://modusbox-docs.s3-website-us-west-2.amazonaws.com/jde/jde/latest/jde.html#copy-jde-ini-files-inside-the-project): _Copy JDE ini Files to the Projet_)
* JDE Enterprise Server is reachable from your location
* EDI Document Type setup is completed in JDE

## Import the project

* Click File &rarr; Import
* On the next screen, click "Packaged mule application (.jar)" &rarr; Next.

![Import Packaged Mule Application](images/ImportProject.png)

* You can now import the demo jar on the next screen.  Locate the demo/ directory from the code base, and add the demo jar file. Assign the demo a project name. 

![Import Mule Project](images/ImportProjectName.png)

## Set Cookbook credentials inside the file `src/main/app/jde.properties`.
```
jde.user=<YOUR_JDE_USER>
jde.password=<YOUR_JDE_PASSWORD>
jde.environment=<YOUR_JDE_ENVIRONMENT>
jde.role=<YOUR_JDE_ROLE> 
```
## Copy **JDE Configuration Files** inside the Project.

The following files need to be located
*	jdbj.ini
*	jdeinterop.ini
*	tnsnames.ora (for Oracle databases only)

Copy these file to your resources folder, as per the enviroment being used to run the demo eg. JDV920
* source/main/resources/**JDV920**

![Copy Ini Files](images/src_main_resources.png)
 

## Update Dependencies ##

*Important Note*: For the demo application, you'll need to update library dependencies (pom.xml in the project root folder).. 

	<dependency>
		<groupId>com.modus</groupId>
		<artifactId>mule-jde-connector</artifactId>
		<version>2.0.0</version>
		<classifier>mule-plugin</classifier>
	</dependency>
-
	<dependency>
		<groupId>com.jdedwards</groupId>
		<artifactId>jde-lib-bundle</artifactId>
		<version>1.0.0</version>
		<classifier>mule-4</classifer>
	</dependency>



## Test Connection ##

* Go to the Global Element tab, select the **"JDE Config"** element, and click "Edit"
* On the button panel the bottom of the window, click **"Test Connection..."**

![Test Connection](images/TestConnection.png)

* If the connection succeeded, you should see the below message.
 
![Test Connection Popup](images/ConnectionSuccess.png)
 
## Testing the Demo ##

* Save the project.
* To run the project, right-click the project name in the project explorer view, select Run As → Mule Application.

![Test Connection Popup](images/RunAs.png)

* Configure Flat File Cross-Reference (P47002)

The last configuration that is needed is inform to JDE connector the EDI outbound:

Using "Flat File Cross-Reference (P47002)" form "Work With Flat File Cross-Reference" adds the following record:

![Test PO](images/P47002.png)

** Table: F47026 - Record Type: 1 Header

** Table: F47027 - Record Type: 2 Detail

** Table: F4706 - Record Type: 6 Address

** Table: F4714 - Record Type: 7 Header Text

** Table: F4715 - Record Type: 8 Detail Text

* Enter a Sales Order and invoke UBE R42565 XJDE0003 [ Batch EDI - P.O. Acknowledgment Transaction (855) ] for the order generated:

![Test PO](images/PO.png)

* Monitor the output Folder, to see the output file created.
 
## About the flows
 
**1. demo-portx-jde-events-ediFlow:** Polls for Purchase Order EDI Events.

![Flow Get](images/MainFlow.png)
 
* **Congratulations!** You have successfully run this demo.
